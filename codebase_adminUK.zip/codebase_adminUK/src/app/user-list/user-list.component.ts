import { Component, OnInit,AfterViewInit, Output,EventEmitter, OnDestroy, ViewChild} from '@angular/core';
import { Subscription,BehaviorSubject, Subject } from 'rxjs';
import {AdminDashboardComponent} from '../admin-dashboard/admin-dashboard.component';
import {AuthService} from '../services/auth.service'; 
import { DataTableDirective } from 'angular-datatables';
import {Defaultval} from '../models/defaultValues';
@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements  OnInit{

  userListSubscription:Subscription;
  userList=[];
  @Output() detailList=new EventEmitter<Boolean>();
  userDetails: BehaviorSubject<any>;  
  @ViewChild(DataTableDirective)
 
  dtElement: DataTableDirective; 
  dtTrigger: Subject<any> = new Subject();
  appStage=Defaultval.appStage;


  constructor( private admin:AdminDashboardComponent, private authService:AuthService) { }

  ngOnInit() {
    
    this.userListSubscription = this.admin.searchResult.subscribe(user => {
    
      this.userList=[];
      this.userList = user;
      
  });
 // this.userListSubscription.unsubscribe();
this.userDetails=new BehaviorSubject<any>('');
 

var that=this;
this.userList.filter(function(obj){
that.appStage.filter(function(matchs){
if(obj.pageId==matchs.value){
  obj.stageName=matchs.name;
}
})
 });

}
 

 
 isEmpty=(obj)=> {
  for (var x in obj) { if (obj.hasOwnProperty(x))  return false; }
  return true;
}
getUserdetail=(emailid)=>{
  console.log(emailid);
  this.detailList.emit(true);
  this.authService.userDetails.next(emailid);
 
}
 

 

}
