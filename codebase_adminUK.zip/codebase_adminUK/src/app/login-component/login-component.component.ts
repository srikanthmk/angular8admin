import { Component, OnInit } from '@angular/core'; 
import {AuthService} from '../services/auth.service';
import { first} from 'rxjs/operators';
import {BehaviorSubject,Subscription} from 'rxjs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpHeaders } from '@angular/common/http';
import { NotificationService } from '../services/notification.service';
import { environment } from '../../environments/environment';
@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {
  env=environment;
  submitted = false;
  loginForm: FormGroup;
  returnUrl: string;
  public errMsg: BehaviorSubject<any>;
  errmsgSub:Subscription;
  errmsgText:string="";

  newErrmsgText: any="";
  errorMessages: any = [];
  notifySubscription: Subscription;

  constructor(private _notifyService : NotificationService, private authService:AuthService, private formBuilder:FormBuilder,
    private route: ActivatedRoute,
    private router: Router) {
        // redirect to home if already logged in
        if (this.authService.currentUserValue) { 
          this.router.navigate(['/']);
      }
      this.errMsg = new BehaviorSubject<any>('');

     }

  ngOnInit() {


      // subscribe to notification messages
      this.notifySubscription = this._notifyService.getMessage().subscribe(message => {
        if (message) {
          this.errorMessages.push(message.data);
          this.newErrmsgText =  message.data.text;
        } else {
          // clear messages when empty message received
          this.errorMessages = [];
          this.newErrmsgText = '';
        }
      });
    this.loginForm = this.formBuilder.group({
      empid: ['', Validators.required],
      password: ['', Validators.required]
  });
 this.errmsgSub= this.errMsg.subscribe(data=>{
    this.errmsgText=data;
     });
     this.errmsgSub.unsubscribe();
  }


   // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }
//this.f.empid.value, this.f.password.value
let aesObj = this.authService.getSaltAndIv(this.f.empid.value,this.f.password.value);

const httpOptions = {
  headers: new HttpHeaders({
    "Content-Type":  'application/json',
    "salt":aesObj.salt.toString(),
    "iv":aesObj.iv.toString()
  })
};
  this.authService.login(aesObj.empid.toString(),aesObj.password.toString(),httpOptions)
  .pipe(first()).subscribe(
      data => {
      console.log(data);
    if(data.success){
      this.router.navigate(["/adminDashboard"]);
    }
    else{

      this.newErrmsgText=data.message;
        this.router.navigate(["/login"]);
    }  
      },
      error => {
         console.log(error);
         this.router.navigate(["/login"]);
      });

}


}
