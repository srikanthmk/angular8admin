import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponentComponent } from './login-component/login-component.component';
import {AdminDashboardComponent} from './admin-dashboard/admin-dashboard.component';
import {UserListDetailComponent} from './user-list-detail/user-list-detail.component';
import {AuthGuard} from './services/auth.guards';
const routes: Routes = [
  {
    path: '', redirectTo: '/login', pathMatch: 'full'},
  {
    path:"login",
    component:LoginComponentComponent
  },
{
  path:"adminDashboard",
  component:AdminDashboardComponent,
  canActivate: [AuthGuard]
},
{path:"userListDetail",
component:UserListDetailComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
