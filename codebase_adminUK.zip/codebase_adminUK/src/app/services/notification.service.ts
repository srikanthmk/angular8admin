import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

// export interface IMessage{
//   text: string,
//   category: string 
// }

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  constructor() { }

  private subject = new BehaviorSubject<any>('');
  
  sendMessage(data) {
      console.log("Sending message: ", data)
      this.subject.next({ data: data }); 
  }

  getMessage(): Observable<any> {
      return this.subject.asObservable();
  }
  
}
