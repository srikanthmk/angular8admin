
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable ,of,Subscription} from 'rxjs';
import { map ,catchError,tap } from 'rxjs/operators'; 
import { environment } from '../../environments/environment';
import * as CryptoES from 'crypto-js'; 
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject: BehaviorSubject<any>;
  currentUserSubscription: Subscription;
  public currentUser: Observable<any>;
  public detailUserData:Observable<any>;
  env=environment;
  public loginToken: BehaviorSubject<any>;
  loginUserData:object=[];
  userDetails: BehaviorSubject<any>; 
  host:any;
  constructor(private http: HttpClient, private router:Router) {
      this.currentUserSubject = new BehaviorSubject<any>("");
      this.currentUser = this.currentUserSubject.asObservable();
      this.loginToken = new BehaviorSubject<any>('');
      this.userDetails=new BehaviorSubject<any>('');
      this.detailUserData=this.userDetails.asObservable();

      this.host=window.location.origin+"/";
     if(document.location.hostname=="localhost"){
         this.host="http://10.24.155.38:9083/";
       }
  }

  public get currentUserValue(): any {
      return this.currentUserSubject.value;
  }

  login(username: string, password: string, httpOptions:object) {
   

      return this.http.post<any>(this.host+this.env.context+'/adminLogin', { loginId: username,
      password: password },httpOptions)
          .pipe(map(user => {
              // login successful if there's a jwt token in the response
              console.log(user);
              if (user && user.tokenId) {
                  // store user details and jwt token in local storage to keep user logged in between page refreshes
               //   localStorage.setItem('currentUser', JSON.stringify(user));
                this.loginToken.next(user.tokenId);
                  this.currentUserSubject.next(user);
              }

              return user;
          }));
  }

  searchUser(inputJson:object) {
    return this.http.post<any>(this.host+this.env.context+'/basicSearch',inputJson)
        .pipe(map(user => {
             return user;
        }));
}
getUserDetails(inputJson:object){
  return this.http.post<any>(this.host+this.env.context+'/fullSearch',inputJson)
  .pipe(map(user=>{return user;}))
}
 

  logout(inputJson:object) {
      // remove user from local storage to log user out
      return this.http.post<any>(this.host+this.env.context+'/logout',inputJson)
      .pipe(map(user=>{return user;})).subscribe(res=>{
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
        this.loginToken.next(null);    
        this.router.navigate(['/']);
      })
         
  }

  



 
  

  // New Algorithm for Login Password - START
  randStringSaltIv=function(x){
    var s = "";
    while(s.length<x&&x>0){
        var r = Math.random();
        s+= (r<0.1?Math.floor(r*100):String.fromCharCode(Math.floor(r*26) + (r>0.5?97:65)));
    }
    return s.toLowerCase();
}
b64EncodeUnicode=function(str) {
    // first we use encodeURIComponent to get percent-encoded UTF-8,
    // then we convert the percent encodings into raw bytes which
    // can be fed into btoa.
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,
        function toSolidBytes(match, p1) {
            return String.fromCharCode(parseInt('0x' + p1, 16));
    }));
}
  getrandomNumber=()=>{
  var length =1;
  var randomNum =
                  (Math.pow(10,length).toString().slice(length-1) +
                  Math.floor((Math.random()*Math.pow(10,length))+1).toString()).slice(-length);
   return randomNum;
}
doubleRandomDigit=(val)=>{
  var doubleVal = val.charAt(val.length-9);
  var doubleVal1 = parseInt(doubleVal);
  doubleVal1 = doubleVal1 + doubleVal1;
  return doubleVal1;
}
insert=(str, index, value)=> {
  return str.substr(0, index) + value + str.substr(index);
}



getSaltAndIv = function (empid:any,password:any) {
let encrypt:any={};
/** ****AES Encryption Algorithm Starts***** */
const salt = CryptoES.lib.WordArray.random(128 / 8);
const iv = CryptoES.lib.WordArray.random(128 / 8);
const key128Bits = CryptoES.PBKDF2("IMB UK Onboard Admin", salt, { keySize: 128 / 32, iterations: 100 });
const encrypted = CryptoES.AES.encrypt(empid, key128Bits, {
iv: iv,
mode: CryptoES.mode.CBC,
padding: CryptoES.pad.Pkcs7
});
const encrypted1 = CryptoES.AES.encrypt(password, key128Bits, {
    iv: iv,
    mode: CryptoES.mode.CBC,
    padding: CryptoES.pad.Pkcs7
    });


var hashsalt = this.randStringSaltIv(4) + salt.toString() + this.randStringSaltIv(6);
var hashiv = this.randStringSaltIv(4) + iv.toString() + this.randStringSaltIv(6);
var b64salt = this.b64EncodeUnicode(hashsalt.trim());
  var b64iv = this.b64EncodeUnicode(hashiv.trim());
  
  var b64saltLen = b64salt.length;
  var b64ivLen = b64iv.length;
  
  var insert9salt = this.insert(b64salt, b64saltLen - 8, this.getrandomNumber());
  var insert9iv = this.insert(b64iv, b64ivLen - 8, this.getrandomNumber());
  
  var addfirstCharSalt = this.randStringSaltIv(1) + insert9salt.toString();
  var addfirstCharIv = this.randStringSaltIv(1) + insert9iv.toString();

  var doubleSaltRand = this.doubleRandomDigit(addfirstCharSalt);
  var doubleIvRand = this.doubleRandomDigit(addfirstCharIv);
  
  var fSalt = this.insert(addfirstCharSalt, doubleSaltRand, this.randStringSaltIv(4));
  var fIv = this.insert(addfirstCharIv, doubleIvRand, this.randStringSaltIv(4));
// New Algorithm for Login Password - END
   
encrypt.salt =  fSalt.toString();
encrypt.iv = fIv.toString();
encrypt.empid=encrypted;
encrypt.password = encrypted1;
return encrypt;
/** ****AES Encryption Algorithm Ends***** */
}
}