import { Component, OnInit ,Output ,EventEmitter} from '@angular/core';
import { Subscription, Observable,BehaviorSubject, from } from 'rxjs'; 
import { map,first } from 'rxjs/operators'; 
import {AuthService} from '../services/auth.service';
import{Userdata} from '../models/userdata';
import{Detailuser} from '../models/Detailuser';
import { NotificationService } from '../services/notification.service';
import { Router, ActivatedRoute } from '@angular/router';
import {Defaultval} from '../models/defaultValues';
import { matchesElement } from '@angular/animations/browser/src/render/shared';
@Component({
  selector: 'app-user-list-detail',
  templateUrl: './user-list-detail.component.html',
  styleUrls: ['./user-list-detail.component.css']
})
export class UserListDetailComponent implements OnInit {
  userDetailsSubscription:Subscription;
  emailid:string="";
  currentUser:Userdata;
  currentUserSubscription: Subscription;
  loginTokenSubscription:Subscription;
  loginToken = '';
  userDetails:Detailuser[];
  showTableContent: boolean = false;
  appStage=Defaultval.appStage;
  employmentStatus=Defaultval.employmentStatus;
  pageCode:string;
  constructor( private authService:AuthService,private _notifyService : NotificationService, private router:Router) {

    this.currentUserSubscription = this.authService.currentUser.subscribe(user => {
      this.currentUser = user.data;
  });
  this.loginTokenSubscription=this.authService.loginToken.subscribe(token=>{
 this.loginToken=token;
  });
  this.userDetailsSubscription = this.authService.detailUserData.subscribe(mailid => {
    this.emailid = mailid;
});
  
  this.currentUserSubscription.unsubscribe();
 // this.loginTokenSubscription.unsubscribe();
  this.userDetailsSubscription.unsubscribe();

   }
//private details:UserListComponent
  ngOnInit() {
    
this.getdetails();
 




  }
getdetails(){

  let inputJson= {
    "banID": this.currentUser.ID,
    "securityToken":this.loginToken,
    "email_ID":this.emailid,
       }
  
  this.authService.getUserDetails(inputJson).pipe(first()).subscribe(
    res => {
 //     console.log(res);
    
      if (res && res.tokenId) {
      this.authService.loginToken.next(res.tokenId);
      this.loginTokenSubscription=this.authService.loginToken.subscribe(token=>{
       this.loginToken=token;
        });
 
        if(res.data[0].pAGE_CODE!=null && res.data[0].pAGE_CODE!=''){
        let pageName=this.appStage.filter(matchs=>matchs.value==res.data[0].pAGE_CODE);
     res.data[0].pAGE_CODE=pageName[0].name;
    }
    if(res.data[0].eMPLOYMENTSTATUS!=null && res.data[0].eMPLOYMENTSTATUS!=''){
        let empStatus=this.employmentStatus.filter(matchs=>matchs.value==res.data[0].eMPLOYMENTSTATUS);
        res.data[0].eMPLOYMENTSTATUS=empStatus[0].name;
      }
     this.userDetails=res.data[0]; 
     this.showTableContent = true;
     console.log(this.userDetails);
       } else{
         let message = res.message; 
         this._notifyService.sendMessage({text: message, category: 'success'});
         this.router.navigate(["/login"]);
       }

       // this.router.navigate(["/adminDashboard"]);
    },
    error => {
       console.log(error);
    });
}



}
