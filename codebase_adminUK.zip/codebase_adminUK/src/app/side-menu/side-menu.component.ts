import { Component, OnInit, Output ,EventEmitter} from '@angular/core';
import{Userdata} from '../models/userdata';
import {AuthService} from '../services/auth.service';
import { Subscription, Observable,BehaviorSubject } from 'rxjs';
import {Defaultval} from '../models/defaultValues';
import { find } from 'rxjs/operators';
@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.css']
})
export class SideMenuComponent implements OnInit {
  @Output() Search = new EventEmitter<Boolean>();
  currentUser:Userdata;
   menuList=Defaultval.menuList;
  mainMenu:object;
  subMenu:object;
  currentUserSubscription: Subscription;
  constructor(private authService:AuthService) {
    
  this.currentUserSubscription = this.authService.currentUser.subscribe(user => {
      this.currentUser = user.data;
  });
this.currentUserSubscription.unsubscribe();
}

     
  ngOnInit() { 
 let test=[];
let fid=this.currentUser.menuIds;
var that=this;
fid.forEach(function(val){  
test.push(that.menuList.find(x=>x.id==val));
})

this.mainMenu=test.filter(x=>x.Pid=='');
this.subMenu=test.filter(x=>x.Pid!='');
console.log(this.mainMenu);
console.log(this.subMenu);
  }


  showSearch=()=>{
this.Search.emit(true);
  }

}
