import { Component, OnInit, Inject , Renderer2,Output,EventEmitter, Input } from '@angular/core';
import {AuthService} from '../services/auth.service';
import { Subscription, Observable,BehaviorSubject } from 'rxjs';
import { DOCUMENT } from '@angular/common';
import{Userdata} from '../models/userdata';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  currentUser:Userdata;
  currentUserSubscription: Subscription;
  toggle:boolean=true;
  @Input() pageTitle:String;
  loginTokenSubscription:Subscription;
  loginToken = '';
  constructor(private authService:AuthService,@Inject(DOCUMENT) private document: Document,private renderer: Renderer2) { 
    this.currentUserSubscription = this.authService.currentUser.subscribe(user => {
      this.currentUser = user;
  });
  this.loginTokenSubscription=this.authService.loginToken.subscribe(token=>{
    this.loginToken=token; 
     });
  }

  ngOnInit() {
  }
  logout=()=>{
    let inputJson={
    "banID": this.currentUser.ID,
    "securityToken":this.loginToken};

  this.authService.logout(inputJson);
  
}

toggleMenu(e){
        this.toggle=e;
         if(this.toggle){
          this.renderer.addClass(this.document.body, 'open');
       
        } else{
          this.renderer.removeClass(this.document.body, 'open');
       
        }
        this.toggle=!this.toggle;
      }
}
