import { Component, OnInit, EventEmitter,OnDestroy,ViewChild, Output } from '@angular/core'; 
import { Subscription, Observable,BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators ,FormControl} from '@angular/forms';
import {AuthService} from '../services/auth.service';
import { environment } from '../../environments/environment';
import { map,first } from 'rxjs/operators'; 
import {formatDate} from '@angular/common'; 
import { Router, ActivatedRoute } from '@angular/router';
import{Userdata} from '../models/userdata';
import { NotificationService } from '../services/notification.service';
import { HeaderComponent } from '../header/header.component';
import {Defaultval} from '../models/defaultValues';
@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit,OnDestroy{
  searchForm: FormGroup;
  submitted:boolean = false;
  showList = false;
  searchDisp:boolean =false ;
  currentUser:Userdata;
  currentUserSubscription: Subscription;
  loginTokenSubscription:Subscription;
  loginToken = '';
  env=environment;
  datefields:any;
  searchResult: BehaviorSubject<any>; 
  detailUser:boolean=false; 
  currentPage:string="Admin - Dashboard";
  searchList=Defaultval.searchList;
  @ViewChild(HeaderComponent) header:HeaderComponent;
  maxDate: Date; 
  minDate:Date;
  constructor(private _notifyService : NotificationService, private formBuilder: FormBuilder, private authService:AuthService, private http:HttpClient,private router:Router) {
    this.currentUserSubscription = this.authService.currentUser.subscribe(user => {
      this.currentUser = user.data;
  });
  this.currentUserSubscription.unsubscribe();
  this.loginTokenSubscription=this.authService.loginToken.subscribe(token=>{
 this.loginToken=token;
 console.log(this.loginToken);
  });
 // this.loginTokenSubscription.unsubscribe();
  this.searchResult=new BehaviorSubject<any>('');


  this.maxDate = new Date();
  this.minDate = new Date();
  this.minDate.setDate(this.minDate.getDate() - 90);
   }

  ngOnInit() {

    this.searchForm = this.formBuilder.group({
      searchcat: ['semail', Validators.required],
      email: ['', [Validators.required,Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,10}|[0-9]{1,3})(\]?)$/)]],
      dob: ['', Validators.required],
      sdate: ['', Validators.required],
      fname: ['', Validators.required],
      lname: ['', Validators.required]
    });
 
 
  }
//details user view
showuserData(e){
  this.searchDisp=false;
  this.showList=false;
  this.detailUser=e;
  this.currentPage="Onboarding - User Details";
 

}

  searchChange=(val)=>{
    console.log(val);
    this.searchForm.reset();
    this.searchForm.controls['searchcat'].patchValue(val);
    this.submitted = false;
  }

  
  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.currentUserSubscription.unsubscribe();
 //   this.loginTokenSubscription.unsubscribe();
}

backTO=()=>{
  this.searchDisp=true;
  this.showList=true;
  this.detailUser=false;
}
  
  // convenience getter for easy access to form fields
  get f() { return this.searchForm.controls; }

  onSubmit() {
    this.submitted = true;
    this.detailUser=false;
    this.showList = false;
    // stop here if form is invalid
    // if (this.searchForm.invalid) {
    //   alert("please search the details");
    //   return;
    // } 
let i=0;
if(this.searchForm.get("searchcat").status=="INVALID"){
i++;
}
if(this.searchForm.get("searchcat").value=="semail" && this.searchForm.get("email").status=="INVALID"){
i++;
 }
if(this.searchForm.get("searchcat").value=="sdob" && this.searchForm.get("dob").status=="INVALID"){
  i++;
  }
  if(this.searchForm.get("searchcat").value=="sname" && (this.searchForm.get("fname").status=="INVALID" && this.searchForm.get("lname").status=="INVALID")){
    i++;
    }
    if(this.searchForm.get("searchcat").value=="sdate" && (this.searchForm.get("sdate").status=="INVALID")){
      i++;
      }
      if(i!=0){
        return;
      }
      let email=this.searchForm.get("email").value 
    if(email!=null && email!=""){
      email=email.toLowerCase();
    }  

let inputJson= {
  "banID": this.currentUser.ID,
  "securityToken":this.loginToken,
  "email_ID":email ,
  "app_strt_date":"",
  "fromDate":this.searchForm.get("sdate").value?formatDate(this.searchForm.get("sdate").value[0],'dd-MM-yyyy', 'en'):'',
  "toDate":this.searchForm.get("sdate").value?formatDate(this.searchForm.get("sdate").value[1],'dd-MM-yyyy', 'en'):'',
  "first_Name":this.searchForm.get("fname").value,
  "last_Name":this.searchForm.get("lname").value,
  "dob":this.searchForm.get("dob").value?formatDate(this.searchForm.get("dob").value, 'dd-MM-yyyy', 'en'):'' 
    }


     
this.authService.searchUser(inputJson).pipe(first()).subscribe(
           res => {
        //     console.log(res);
             if (res && res.tokenId) {
              this.searchResult.next(res.data);
             this.authService.loginToken.next(res.tokenId);
             this.loginTokenSubscription=this.authService.loginToken.subscribe(token=>{
              this.loginToken=token;
              console.log("basic search: "+this.loginToken);
               });

        //       this.loginTokenSubscription.unsubscribe();
               this.showList = true;
               this.header.toggleMenu(true);
              } else{
                let message = res.message; 
                this._notifyService.sendMessage({text: message, category: 'success'});
                this.router.navigate(["/login"]);
              }

              // this.router.navigate(["/adminDashboard"]);
           },
           error => {
              console.log(error);
           });



  }

  Search(e) {
    this.searchDisp=e;
    this.detailUser=false;
    this.currentPage="Onboarding - Search";
  } 
}
