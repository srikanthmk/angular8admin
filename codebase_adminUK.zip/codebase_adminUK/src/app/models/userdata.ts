export interface Userdata {
    EmployeeName:string,
    ID:string,
    LastLogin:string,
    Role:string,
    UserName:string,
    currentLogin:string,
    menuIds:[]
}
