export const Defaultval ={
  "menuList":[
    {id:"100",name:"Onboarding",path:"",Pid:""},
    {id:"200",name:"Onboarding1",path:"",Pid:""},
    {id:"101",name:"Search",path:"",Pid:"100"},
    {id:"102",name:"sibmenu2",path:"",Pid:"100"},
    {id:"201",name:"submenu11",path:"",Pid:"200"},
    {id:"202",name:"sibmenu22",path:"",Pid:"200"}  ],
    "searchList":[{"name":"Email","value":"semail"},{"name":"Application Start Date","value":"sdate"},{"name":"First or Last Name","value":"sname"},{"name":"Date of Birth","value":"sdob"}],
    "appStage":[
      {name:"AOF not Initiated",value:""},
      {name:"AOF not Initiated",value:"Login"},
      {name:"Personal Details",value:"PD"},
      {name:"Contact Details",value:"CD"},
      {name:"Address Details",value:"AD"},
      {name:"Identification Details",value:"ID"},
      {name:"Jumio Completed",value:"JumioS"},
      {name:"Jumio not Completed",value:"JumioNS"},
      {name:"Jumio not Completed",value:"AOF1"},
      {name:"Financial Details",value:"FD"},
      {name:"Tax Residency Details",value:"TD"},
      {name:"Marketing Details",value:"MD"},
      {name:"Authorization",value:"AT"},
      {name:"Application Submitted - NSTP",value:"NSTP"},
      {name:"Application Submitted - STP",value:"IKIT"},
      {name:"STP - Account activated",value:"ACT"},
      {name:"STP - RIB Password created",value:"IBACT"},
      {name:"Application Submitted - Dedupe",value:"NSTPD"},
      {name:"Discrepancy Received",value:"HDISC"},
      {name:"Discrepancy Received",value:"SDISC"},
      {name:"Discrepancy Received",value:"HSDISC"},
      {name:"User Submitted Discrepancy",value:"DISCSUB"}],
      "employmentStatus": [
        {
          "name": "Employed Full time",
          "value": "010"
        },
        {
          "name": "Self Employed",
          "value": "006"
        },
        {
          "name": "Home maker",
          "value": "003"
        },
        {
          "name": "Unemployed",
          "value": "*"
        },
        {
          "name": "Retired",
          "value": "007"
        }
      ]
};