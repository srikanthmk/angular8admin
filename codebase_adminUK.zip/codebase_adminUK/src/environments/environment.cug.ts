export const environment = {
    production: true,
    context:"imobileukadminservices"
  };
  